// import { number, string } from "joi";
import mongoose from "mongoose";



const productSchema = new mongoose.Schema({
    title: {
        type: String,
        unique: true // `email` must be unique
    },
    description: String,
    task: [
        {
            id: Number,
            title: String,
            description: String,
            order: Number,
            stage: String,
            index: Number,
            attachment: [
                { type: String, url: String }
            ],
            created_at: { type: Date, default: Date.now },
            updated_at: { type: Date, default: Date.now },
        }
    ]
})



export default mongoose.model('Project', productSchema);
// module.exports = mongoose.model("product", productSchema);
